document.addEventListener("DOMContentLoaded", function() {
    const ctx = document.getElementById("myChart").getContext("2d");

    new Chart(ctx, {
        type: "bar",
        data: {
            labels: ["Stock", "Profit", "Visitors"],
            datasets: [{
                label: "Data",
                data: [150000, 25000, 250000],
                backgroundColor: ["#9b59b6", "#3498db", "#e67e22"]
            }]
        },
        options: {
            responsive: true
        }
    });
});